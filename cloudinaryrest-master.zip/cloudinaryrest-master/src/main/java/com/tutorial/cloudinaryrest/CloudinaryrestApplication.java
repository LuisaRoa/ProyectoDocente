package com.tutorial.cloudinaryrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudinaryrestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudinaryrestApplication.class, args);
	}

}

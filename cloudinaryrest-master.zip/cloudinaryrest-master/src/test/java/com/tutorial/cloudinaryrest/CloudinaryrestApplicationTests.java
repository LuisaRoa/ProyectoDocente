package com.tutorial.cloudinaryrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudinaryrestApplicationTests {

	@Test
	void contextLoads() {
	}

}
